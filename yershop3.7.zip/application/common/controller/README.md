 yershop
基于thinkphp5的开源网店系统，官网 http://yershop.com/ 


### 1.安装环境要求如下：
```

PHP >= 5.4.0
mysql >= 5.0
PDO PHP Extension
MBstring PHP Extension
CURL PHP Extension
```

### 2.执行安装


xxx.com/install.php或访问域名进入安装向导

#后台xxx.com/admin.php